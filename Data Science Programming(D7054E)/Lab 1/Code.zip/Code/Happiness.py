from Dataset import Dataset

class HappinessDataset(Dataset):
    def dataset_name(self):
        return "HappinessDataset"
