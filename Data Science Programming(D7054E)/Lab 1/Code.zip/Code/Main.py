from Happiness import HappinessDataset
from Covid_19 import Covid_19_Dataset

# Function to pick the best column for entity search
def pick_entity_column(cols):
    preferred = ["Country", "Name"]
    lower_map = {c.lower(): c for c in cols}

    for p in preferred:
        if p.lower() in lower_map:
            return lower_map[p.lower()]

    for c in cols:
        cl = c.lower()
        if "country" in cl or cl == "name":
            return c
    return None

# Main function to demonstrate dataset functionalities
def main():
    happiness_file = "World_Happiness_2019.csv"
    covid_file = "WHO COVID-19 data.csv"

    happiness_ds = HappinessDataset(happiness_file)
    covid_ds = Covid_19_Dataset(covid_file)

    datasets = [happiness_ds, covid_ds]

    for ds in datasets:
        print("\n" + "=" * 60)
        print(ds.get_data_info())

        cols = ds.get_columns()
        print("Columns:")
        print(cols)

        numeric_cols = ds.get_numeric_columns()
        print("Numeric columns:")
        print(numeric_cols)

        for col in numeric_cols:
            stats = ds.statistics(col)
            mn, mx = ds.min_max(col)
            # Display statistics
            print(f"\n[{col}]")
            print(f"  mean      = {stats['mean']}")
            print(f"  variance  = {stats['variance']}")
            print(f"  std       = {stats['std']}")
            print(f"  min       = {mn}")
            print(f"  max       = {mx}")

        # Search for an entity
        entity_col = pick_entity_column(cols)
        if entity_col:
            value = "Finland" if ds.dataset_name() == "HappinessDataset" else "India"
            matches = ds.search(entity_col, value)
            print(f"\nSearch: {entity_col} = {value}")
            print("Matches found:", len(matches))
            for r in matches:
                print(r)
        else:
            print("\n No Country column found.")


if __name__ == "__main__":
    main()
