import csv
import math
from typing import Any, Dict, List, Optional, Tuple #To clarify and organize the types of data used.


class Dataset:
    # constructor
    def __init__(self, csv_path: str, max_rows: int = 10):
        self.csv_path = csv_path
        self.max_rows = max_rows
        self.rows: List[Dict[str, Any]] = []
        self._columns: List[str] = []
        self.data_loader()

    # function to attempt converting a value to float, returning None for invalid cases.
    @staticmethod
    def float_converter(x: Any) -> Optional[float]:
        if x is None:
            return None

        s = str(x).strip()  # convert to string and remove whitespace and special cases
        if s == "" or s.lower() in {"na", "n/a", "null", "none"}:
            return None

        try:
            return float(s)  # return float value if conversion is successful else None
        except ValueError:
            return None

    def dataset_name(self) -> str:
        return "Dataset"


    # Cleans a row by stripping whitespace from string values.
    def clean_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        for k, v in row.items(): # iterate through each key-value pair in the row
            if isinstance(v, str): # if the value is a string
                row[k] = v.strip() # remove leading and trailing whitespace
        return row



    def data_loader(self) -> None:
        with open(self.csv_path, newline="", encoding="utf-8") as f: # open the CSV file
            reader = csv.DictReader(f) # read the CSV file as a dictionary

            raw_columns = reader.fieldnames or [] # get the column names from the CSV
            self._columns = [c.replace("\ufeff", "").strip() for c in raw_columns] # remove BOM and whitespace

            self.rows = [] # initialize an empty list to store the rows
            for i, r in enumerate(reader): # iterate through each row in the CSV
                if i >= self.max_rows:  # limit the number of rows to be loaded
                    break

                cleaned_row = {} # initialize an empty dictionary for the cleaned row
                for k, v in r.items(): # iterate through each key-value pair in the row
                    if isinstance(k, str): # if the key is a string
                        k = k.replace("\ufeff", "").strip() # remove BOM and whitespace from the key
                    cleaned_row[k] = v # add the cleaned key-value pair to the cleaned row

                self.rows.append(self.clean_row(cleaned_row))# send the cleaned row to clean_row to clean it and then store it in the rows list

    # return the list of column names
    def get_columns(self) -> List[str]: 
        return list(self._columns)

    # return a description of the dataset (total number of rows and columns)
    def get_data_info(self) -> str:
        return f"{self.dataset_name()}: {len(self.rows)} rows, {len(self._columns)} columns"

    # return all values in a specified column
    def get_column_values(self, col: str) -> List[Any]:
        return [r.get(col) for r in self.rows]

    # return a list of numeric columns
    def get_numeric_columns(self) -> List[str]:
        numeric = [] # initialize an empty list to store numeric columns
        for col in self._columns: # iterate through each column
            vals = [self.float_converter(v) for v in self.get_column_values(col)] # convert all values in the column to float
            nums = [v for v in vals if v is not None] # filter out non-numeric values
            # The number should contians two digits at least, at least 70% of the values should be numeric
            if len(nums) >= 2 and len(nums) >= max(2, int(0.7 * max(1, len(vals)))):
                numeric.append(col) # add the column to the numeric list
        return numeric

    # return statistics (mean, variance, std) for a specified numeric column
    def statistics(self, col: str) -> Dict[str, float]:
        vals = [self.float_converter(v) for v in self.get_column_values(col)]
        nums = [v for v in vals if v is not None]
        if len(nums) < 2: #at least two numeric values are required to compute statistics
            raise ValueError(f"Not enough numeric values in column '{col}'")

        n = len(nums)
        mean = sum(nums) / n
        var = sum((x - mean) ** 2 for x in nums) / (n - 1)  # sample variance calculation
        std = math.sqrt(var)
        return {"mean": mean, "variance": var, "std": std}

    # return the minimum and maximum values for a specified numeric column
    def min_max(self, col: str) -> Tuple[float, float]:
        vals = [self.float_converter(v) for v in self.get_column_values(col)]
        nums = [v for v in vals if v is not None]
        if not nums:
            raise ValueError(f"No numeric values in column '{col}'")
        return min(nums), max(nums)

    # return rows where the specified column matches the given value (case-insensitive)
    def search(self, col: str, value: str) -> List[Dict[str, Any]]:
        if col not in self._columns:
            raise ValueError(f"Column '{col}' not found. Available: {self._columns}")

        target = str(value).strip().lower()
        return [r for r in self.rows if str(r.get(col, "")).strip().lower() == target]
