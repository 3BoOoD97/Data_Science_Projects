from Dataset import Dataset

class Covid_19_Dataset(Dataset):
    def dataset_name(self):
        return "Covid_19_Dataset"
